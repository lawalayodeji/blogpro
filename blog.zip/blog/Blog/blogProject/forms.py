from django import forms
from django_summernote.fields import SummernoteTextFormField
from .models import Post
STATUS = (
    (0,"Draft"),
    (1,"Publish")
)

class BlogForm(forms.ModelForm):
    title = forms.CharField(max_length=200)
    slug = forms.SlugField(max_length=200)
    content= SummernoteTextFormField()

    class Meta:
        model = Post
        fields = ['title', 'slug', 'content', 'status']





