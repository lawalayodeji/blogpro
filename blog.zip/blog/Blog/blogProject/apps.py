from django.apps import AppConfig


class BlogprojectConfig(AppConfig):
    name = 'blogProject'
