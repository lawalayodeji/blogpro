from django.urls import path
from .views import *



urlpatterns = [
    path("", PostListView.as_view(), name="Homep"),
    path("Post", PostCreateView.as_view(), name="FormPost"),
    path("Post/update/<slug:slug>/", PostUpdateView.as_view(), name="PostUpdate"),
    path("Post/delete/<slug:slug>/", PostDeleteView.as_view(), name="PostDelete"),
]