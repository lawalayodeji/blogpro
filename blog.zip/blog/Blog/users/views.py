from django.shortcuts import render, redirect, get_object_or_404
from django.views import generic
from django.contrib import messages
from .forms import UserRegisterForm, UserUpdateForm, ProfileUpdateForm, commentUserForm
from django.contrib.auth.decorators import login_required
from blogProject.models import Post
from .models import Comment
def registerUser(request):
    if request.method == "POST":
        form = UserRegisterForm(request.POST)
        if form.is_valid():
            form.save()
            username = form.cleaned_data.get('username')
            messages.success(request, f"Account created for {username}")
            return redirect("Login")

    else:
        form = UserRegisterForm()


    return render(request, 'users/register.html', {'form': form})

@login_required
def profile(request):
    if request.user.is_superuser:
        if request.method =="POST":
            user_form  = UserUpdateForm(request.POST, instance=request.user)
            profile_form = ProfileUpdateForm(request.POST, request.FILES, instance=request.user.profile)
            
            if user_form.is_valid() and profile_form.is_valid():
                user_form.save()
                profile_form.save()
        else:
            user_form  = UserUpdateForm(instance=request.user)
            profile_form = ProfileUpdateForm(instance=request.user.profile)
        context = {
            'u_form': user_form,
            'p_form': profile_form
        }
        return render(request, 'users/profile.html', context)
    else:
        return redirect("Homep")

def PostDetail(request, slug):
    post = get_object_or_404(Post, slug=slug)
    comment = Comment.objects.filter(post=post)

    if request.method =="POST":
        user_comment = commentUserForm(request.POST)
        
        if user_comment.is_valid():
            # user_comment.save()
            pass
    else:
        user_comment = commentUserForm()
        context = {
        'post':post,
        'u_comment_fo': user_comment,
        }
    return render(request, 'blogProject/post_detail.html', context)




# class PostDetail(generic.DetailView):
#     model = Post
#     template_name = 'blogProject/post_detail.html'
    
    