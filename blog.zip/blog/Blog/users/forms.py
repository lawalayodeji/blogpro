from django import forms
from django.contrib.auth.forms import UserCreationForm
from .models import Profile, User, Comment
class UserRegisterForm(UserCreationForm):
    email = forms.EmailField()

    class Meta:
        model = User
        fields = ['username', 'email', 'password1', 'password2']

class UserUpdateForm(forms.ModelForm):
     email = forms.EmailField()

     class Meta:
         model = User
         fields = ['username', 'email']
    

class ProfileUpdateForm(forms.ModelForm):
    class Meta:
        model = Profile
        fields = ['image']

class customUserForm(UserCreationForm):
    class Meta:
        model = User
        fields = "__all__"

class commentUserForm(forms.ModelForm):
    
    content = forms.CharField(widget=forms.Textarea(attrs={'rows':'4', 'cols':'50'}))
    class Meta:
        model = Comment
        fields = ("content",)









