from django.urls import path
from users.views import *



urlpatterns = [
     path('register', registerUser, name='register'),
     path('profile', profile, name='Profile'),
    path('Post/<slug:slug>/', PostDetail, name='post_detail'),

     

]