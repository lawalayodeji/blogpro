from django.contrib import admin
from .models import Profile,Comment,User
from django.contrib.auth.admin import UserAdmin
from .forms import customUserForm
admin.site.register(Profile)
admin.site.register(Comment)

class CustomUserAdmin(UserAdmin):
    model = User
    add_form = customUserForm

    fieldsets = (
        *UserAdmin.fieldsets,
        (
            'User role',
            {
                'fields':(
                    'is_comment_user',
                )
            }
        )
    )

admin.site.register(User, CustomUserAdmin)

