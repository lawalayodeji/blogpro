from django.db import models
from django.contrib.auth.models import AbstractUser
from blogProject.models import Post

class User(AbstractUser):
    email = models.EmailField(max_length=40, unique=True)
    is_comment_user = models.BooleanField(default=False)


    def __str__(self):
        return self.email

class Profile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    image= models.ImageField(default="default.jpg", upload_to="profile_pics")

    def __str__(self):
        return f"{self.user.username} Profile"

class Comment(models.Model):
    post = models.ForeignKey(Post,on_delete=models.CASCADE)
    user = models.ForeignKey(User,on_delete=models.CASCADE)
    reply =models.ForeignKey('Comment', null=True, related_name='replies', on_delete=models.CASCADE)
    content = models.TextField(max_length=100)
    timestamp = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f'{self.post.title},{self.user.username}'


# class Commentuser(models.Model):
#     username = models.CharField(max_length=20, unique=True)
#     email = models.EmailField(max_length=40,unique=True)
#     is_comment_user = models.BooleanField(default=True)


